#include "world.h"
#include <dlfcn.h>
#include <stdio.h>

/* ------------------------------------------------------------------------- */
/*                                                                           */
/* ------------------------------------------------------------------------- */
void load_players(int argc, char *argv[])
{
    char *error;
    int i = 0;
    void *handle;
    for (i = 1; i < MAX_PLAYERS; i++)
    {
        printf("%s", argv[i]);
        players[i]->so_handle = dlopen(argv[i], RTLD_LAZY);
        handle = players[i]->so_handle;
        if (!handle)
        {
            fputs(dlerror(), stderr);
            exit(1);
        }

        players[i]->get_action = dlsym(handle, "get_action");
        if ((error = dlerror()) != NULL)
        {
            fputs(error, stderr);
            exit(1);
        }
    }
}