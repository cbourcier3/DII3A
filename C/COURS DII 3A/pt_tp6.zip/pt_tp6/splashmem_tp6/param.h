#ifndef __PARAM__
#define __PARAM__

#define MAX_PLAYERS 4
#define MAP_SIZE 100
#define SPOT_NUM MAP_SIZE * MAP_SIZE
#define SQUARE_SIZE 6
#define WIN_SIZE MAP_SIZE * SQUARE_SIZE

#endif 